package com.aditya.kalkulatorbidangdatar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText inp1, inp2;
    TextView txtreskel, txtresluas;

    //Aditya Herdiansyah Putra
    //A11.2021.13948

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initComponent();
    }

    public void initComponent(){
        inp1 = findViewById(R.id.inp1);
        inp2 = findViewById(R.id.inp2);
        txtreskel = findViewById(R.id.txtreskel);
        txtresluas = findViewById(R.id.txtresluas);
    }

    public void Persegi(View v){
        double pjng = Double.parseDouble(inp1.getText().toString());
        double lbr = Double.parseDouble(inp2.getText().toString());

        double luas = pjng*lbr;
        double keliling = 2*(pjng+lbr);
        txtresluas.setText("Luas Persegi : "+luas+" cm");
        txtreskel.setText("Keliling Persegi : " +keliling+ " cm");
    }
    public void Segitiga(View v){
        double alas = Double.parseDouble(inp1.getText().toString());
        double tinggi = Double.parseDouble(inp2.getText().toString());

        double luas = (alas*tinggi) / 2.0;
        double keliling = alas * 3.0;
        txtresluas.setText("Luas Segitiga : "+luas+" cm");
        txtreskel.setText("Keliling Segitiga : " +keliling+ " cm");
    }
    public void lingkaran(View v){
        double jari = Double.parseDouble(inp1.getText().toString()) / 2.0;
        double diameter = Double.parseDouble(inp1.getText().toString());

        double luas = Math.PI * jari * jari ;
        double keliling = Math.PI * diameter;
        txtresluas.setText("Luas Lingkaran : "+luas+" cm");
        txtreskel.setText("Keliling Lingkaran : " +keliling+ " cm");
    }
}