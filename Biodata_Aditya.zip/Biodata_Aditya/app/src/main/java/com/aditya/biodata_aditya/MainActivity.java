package com.aditya.biodata_aditya;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void maps(View view){
        String url="https://goo.gl/maps/jJFL4R84RcMzKQQA9";
        Intent maps = new Intent(Intent.ACTION_VIEW);
        maps.setData(Uri.parse(url));
        startActivity(maps);

    }
    public void call(View v) {

        Intent call = new Intent(Intent.ACTION_DIAL);
        call.setData(Uri.fromParts("tel", "089616857439", null));
        startActivity(call);
    }

    public void email(View view){
        Intent SendEmail = new Intent(Intent.ACTION_SENDTO);
        SendEmail.setData(Uri.parse("mailto: 111202113948@mhs.dinus.ac.id"));
        startActivity(SendEmail);
    }
}